import parent
print(locals())
print(__name__)
