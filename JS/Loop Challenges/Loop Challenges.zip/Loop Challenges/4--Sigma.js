var sum = 0;

for (var i = 0; i <= 100; i++) {
    sum += i;
    console.log(sum);
}