for (var i = 4; i > -4; i -= 1.5) {
    console.log(i);
}