var product = 1;

for (var i = 1; i <= 12; i++) {
    product *= i;
    console.log(product);
}