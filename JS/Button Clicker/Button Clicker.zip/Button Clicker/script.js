function logOut(element) {
    element.innerText = "Logout";
}
function hideBtn(element) {
    element.remove();
}
function alert(ninja) {
    console.log("Ninja was liked", ninja);
}
