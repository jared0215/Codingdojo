import "./App.css";
import {
    BrowserRouter,
    Routes,
    Route,
    Link,
    useParams,
} from "react-router-dom";
import Search from "./components/Search";
import axios from "axios";
import { useState } from "react";
import People from "./components/People";
import Planets from "./components/Planets";

function App() {
    const [responseData, setResponseData] = useState({ results: [] });
    return (
        <BrowserRouter>
            <div className="App">
                <Search
                    responseData={responseData}
                    setResponseData={setResponseData}
                />
                <Routes>
                    <Route
                        path="/people/:id"
                        element={<People responseData={responseData} />}
                    />
                    <Route
                        path="/planets/:id"
                        element={<Planets responseData={responseData} />}
                    />
                </Routes>
            </div>
        </BrowserRouter>
    );
}

export default App;
