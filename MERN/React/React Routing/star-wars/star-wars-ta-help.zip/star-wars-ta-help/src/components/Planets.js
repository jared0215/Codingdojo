import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Planets = ({ responseData }) => {
    return (
        <div>
            <h1>{responseData.name}</h1>
            <p>Climate: {responseData.climate}</p>
            <p>Terrain: {responseData.terrain}</p>
            <p>Surface Water: {responseData.surface_water}</p>
            <p>Population: {responseData.population}</p>
        </div>
    );
};

export default Planets;
