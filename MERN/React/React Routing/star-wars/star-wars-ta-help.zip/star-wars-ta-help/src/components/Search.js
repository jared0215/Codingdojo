import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Planets from "./Planets";
import People from "./People";

const Search = ({ responseData, setResponseData }) => {
    // const [responseData, setResponseData] = useState({ results: [] });

    const [searchTerm, setSearchTerm] = useState("people");
    const [id, setId] = useState(1);
    const navigate = useNavigate();

    // useEffect(() => {
    //     axios
    //         .get(`https://swapi.dev/api/${searchTerm}/${id}`)
    //         .then((response) => {
    //             setResponseData(response.data);
    //         })
    //         .catch((err) => console.log(err));
    // }, [searchTerm, id]);

    const handleSearch = (e) => {
        setSearchTerm(e.target.value);
    };
    const handleId = (e) => {
        setId(e.target.value);
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        axios
            .get(`https://swapi.dev/api/${searchTerm}/${id}`)
            .then((response) => {
                setResponseData(response.data);
            })
            .catch((err) => console.log(err));
        navigate(`/${searchTerm}/${id}`);
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <label htmlFor="search">Search for: </label>
                <select id="search" onChange={handleSearch}>
                    <option value="people">People</option>
                    <option value="planets">Planets</option>
                </select>
                <label htmlFor="id">ID: </label>
                <input type="text" value={id} onChange={handleId} />
                <button type="submit">Search</button>
            </form>
            {/* {searchTerm === "people" ? (
                <People responseData={responseData} />
            ) : null} */}
            {/* {searchTerm === "planets" ? (
                <Planets responseData={responseData} />
            ) : null} */}
        </div>
    );
};

export default Search;
