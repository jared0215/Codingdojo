import "./App.css";
import BoxGen from "./components/BoxGen";

function App() {
    return (
        <div className="App">
            <BoxGen />
        </div>
    );
}

export default App;
