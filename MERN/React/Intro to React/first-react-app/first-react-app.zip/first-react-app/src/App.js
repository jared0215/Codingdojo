import logo from "./logo.svg";
import "./App.css";

function App() {
  return (
    <>
      <h1>Hello Dojo!</h1>
      <h3>Things I need to do:</h3>
      <ul>
        <li>Learn React</li>
        <li>Climb Mt. Everest</li>
        <li>Run a Marathon</li>
        <li>Feed the dogs</li>
      </ul>
    </>
  );
}

export default App;
